const container = document.getElementById("reserva-container");
const adminSelect = document.getElementById("adminSelect");

function criarReservas() {
  container.innerHTML = "";
  adminSelect.innerHTML = "";

  const reservas = [
    { nome: "Holambra - São Paulo", preco: 300 },
    { nome: "Paraty - Rio de Janeiro", preco: 280 },
    { nome: "Ouro Preto - Minas Gerais", preco: 250 },
    { nome: "Florianópolis - Santa Catarina", preco: 320 },
    { nome: "Praia do Gunga - Alagoas", preco: 270 },
    { nome: "Morro de São Paulo - Bahia", preco: 290 },
    { nome: "Jericoacoara - Ceará", preco: 350 },
    { nome: "Manaus - Amazonas", preco: 260 },
    { nome: "Lençóis Maranhenses - Maranhão", preco: 310 },
    { nome: "Caruaru - Pernambuco", preco: 240 },
  ];

  reservas.forEach((r, i) => {
    const div = document.createElement("div");
    div.className = "reserva-box";
    div.setAttribute("data-nome", r.nome);
    div.setAttribute("data-preco", r.preco);
    div.setAttribute("data-id", `reserva-${i}`);
    div.innerHTML = \`
      <img src="https://via.placeholder.com/300x180?text=\${encodeURIComponent(r.nome)}" alt="\${r.nome}" id="img-\${i}">
      <h4 id="nome-\${i}">\${r.nome}</h4>
      <p id="preco-\${i}">R$ \${r.preco},00 / noite</p>
      <a href="#" class="botao-efeito">Reservar</a>
    \`;
    container.appendChild(div);

    const opt = document.createElement("option");
    opt.value = i;
    opt.text = r.nome;
    adminSelect.appendChild(opt);
  });
}

function buscarReserva() {
  const input = document.getElementById("searchInput").value.toLowerCase();
  document.querySelectorAll(".reserva-box").forEach(reserva => {
    const nome = reserva.getAttribute("data-nome").toLowerCase();
    reserva.style.display = nome.includes(input) ? "inline-block" : "none";
  });
}

function filtrarPorOrcamento() {
  const orcamento = parseFloat(document.getElementById("orcamentoInput").value);
  document.querySelectorAll(".reserva-box").forEach(reserva => {
    const preco = parseFloat(reserva.getAttribute("data-preco"));
    reserva.style.display = isNaN(orcamento) || preco <= orcamento ? "inline-block" : "none";
  });
}

function editarReserva() {
  const id = adminSelect.value;
  const nome = document.getElementById("adminNome").value;
  const imagem = document.getElementById("adminImagem").value;
  const preco = document.getElementById("adminPreco").value;
  if (nome) document.getElementById(`nome-${id}`).innerText = nome;
  if (imagem) document.getElementById(`img-${id}`).src = imagem;
  if (preco) {
    document.getElementById(`preco-${id}`).innerText = `R$ ${preco},00 / noite`;
    document.querySelector(`[data-id='reserva-${id}']`).setAttribute("data-preco", preco);
  }
}

function verificarSenha() {
  const senha = document.getElementById("senhaAdmin").value;
  if (senha === "Aline") {
    document.getElementById("admin-login").style.display = "none";
    document.getElementById("admin-panel").style.display = "block";
  } else {
    alert("Senha incorreta!");
  }
}

criarReservas();
